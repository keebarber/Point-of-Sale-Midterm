$(function () {

$(".item").on("click",  function() {
	var addtocart = $(this).html();
	$("#itemsincart").append("<div class='itemincart'>" + addtocart + "</div>");
	
});

// $(document).ready(function(){
//     $("#remove-all").click(function(){
// 		var removeFromCart = $(this).html();
//         	$("#itemsincart").remove();
//     });
// });




// add item to shopping cart


// remove item from shopping cart







});

